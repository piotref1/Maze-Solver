/*#include <SFML/OpenGL.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
*/
#include "Buttons.h"
#include "Movement.h"
#include <string>
#include <iostream>
#include <list>
#include "Checks.h"
/*
using namespace std;

int main()
{
    string Background_Array[13] = { "Background.png" };   //Idea is to declare all sprites. Store them as strings in array. 
    string Player_Array[3] = { "Wall.png" };
    string NPC_Array[13] = { "Road.png" };
  

    sf::Sprite background;
    sf::Texture backgroundTexture;
    backgroundTexture.loadFromFile(Background_Array[3]);
    background.setTexture(backgroundTexture);
    
    sf::Sprite Button1;
    sf::Texture button1Texture;
    button1Texture.loadFromFile("Start.png");
    Button1.setTexture(button1Texture);
    Button1.setPosition(553, 575);

    sf::Sprite Button2;
    sf::Texture button2Texture;
    button2Texture.loadFromFile("Load.png");
    Button2.setTexture(button2Texture);
    Button2.setPosition(553, 675);

    sf::Sprite Button3;
    sf::Texture button3Texture;
    button3Texture.loadFromFile("Design.png");
    Button3.setTexture(button3Texture);
    Button3.setPosition(553, 775);



    
    bool run = true;
    while (run)
    {
        sf::Event event;

        while (window.pollEvent(event))
        {

            if (event.type == sf::Event::MouseButtonPressed)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    window.clear();


                    window.draw(background);
                    window.draw(Button1);
                    window.draw(Button2);
                    window.draw(Button3);
                    window.draw(Wall);
                    window.display();
                    
                        //Start//
                        if((event.mouseButton.x >= 553 && event.mouseButton.x<=653) && (event.mouseButton.y>=575 && event.mouseButton.y<=625))
                        {
                            std::cout << "LEEEEET'S RUUUUUUUUUMBLE" << std::endl;
                        }

                        if ((event.mouseButton.x >= 553 && event.mouseButton.x <= 653) && (event.mouseButton.y >= 675 && event.mouseButton.y <= 725))
                        {
                            std::cout << "Lock and Load" << std::endl;
                        }

                        if ((event.mouseButton.x >= 553 && event.mouseButton.x <= 653) && (event.mouseButton.y >= 775 && event.mouseButton.y <= 825))
                        {
                            std::cout << "#GraphicDesignIsMyPassion" << std::endl;
                        }

                     
                    
                }
            }

        }


    }
    std::cout << "Hello World!\n";
}
*/


int main()
{
    // create the window
    sf::RenderWindow window(sf::VideoMode(704, 704), "Tilemap");

    // define the level with an array of tile indices
    int level[] =
    {
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
        3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    };

    // create the tilemap from the level definition
    TileMap map;

    int size_x;
    int size_y;
    int coord;
    int x;
    int current_pos;
    bool proper_check=false;
    // run the main loop
    while (window.isOpen())
    {
       // std::cin >> x;
        //level[23] = x;
        
        // handle events
        sf::Event event;
        while (window.pollEvent(event))
        {

            WINDOWINFO wiInfo;
            GetWindowInfo(window.getSystemHandle(), &wiInfo);
            //std::cout << "Window Render Area width" << std::endl;
            //std::cout << wiInfo.rcClient.right - wiInfo.rcClient.left << std::endl;
           // std::cout << "Window Render Area height" << std::endl;
            //std::cout << wiInfo.rcClient.bottom - wiInfo.rcClient.top << std::endl;


            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Space)
                {
                    //add start.
                    current_pos=check(level);
                    int current_number = 4;
                    std::cout << "Current pos= " << current_pos << std::endl;
                    if(current_pos>0)movement(level, current_pos, current_number);
                }

                if (event.key.code == sf::Keyboard::S)
                {
                    save(level);
                }

                if (event.key.code == sf::Keyboard::L)
                {
                    load(level);
                }

            }
            if (event.type == sf::Event::MouseButtonPressed)
            {
                if (event.mouseButton.button == sf::Mouse::Left)
                {
                    
                    size_x = (wiInfo.rcClient.right - wiInfo.rcClient.left) / 22;
                    size_y = (wiInfo.rcClient.bottom - wiInfo.rcClient.top) / 22;
                    std::cout << "sizex= " << size_x << " size y= " << size_y << std::endl;
                    std::cout << "pos x= " << event.mouseButton.x/size_x << "pos y= " << event.mouseButton.y/size_y << std::endl;
                    coord = (event.mouseButton.y / size_y) * 22 + (event.mouseButton.x / size_x);

                    /*if ((coord >= 0 && coord <= 22) || (coord >= 461 && coord <= 483) || 
                        coord == 44 || coord == 66 || coord == 88 || coord == 110 || coord == 132 || coord == 154 || coord == 176 || 
                        coord == 198 || coord == 220 || coord == 242 || coord == 264 || coord == 286 || coord == 308 || coord == 330 || 
                        coord == 352 || coord == 374 || coord == 396 || coord == 418 || coord == 440 || coord ==43 || coord ==65 || 
                        coord ==87 || coord ==109 || coord ==131 || coord ==153 || coord ==175 || coord ==197 || coord ==219 || 
                        coord ==241 || coord ==263 || coord ==285 || coord ==307 || coord ==329 || coord ==351 || coord ==373 || 
                        coord ==395 || coord ==417 || coord ==439) */
                    if((coord >= 0 && coord <= 22) || (coord >= 461 && coord <= 483) || (coord %22 )==0 || (coord%22)==21)
                    { level[coord] = 0; } //https://discord.com/channels/538841100337807360/538841100337807364/826198423812309024
                    else level[coord] = level[coord] + 1;

                    if (level[coord] > 3) { level[coord] = 0; }
                    
                }

                if (event.mouseButton.button == sf::Mouse::Right)
                {
                    
                    
                }
            }
        }
        if (!map.load("tileset.png", sf::Vector2u(32, 32), level, 22, 22))
            return -1;
        // draw the map
        window.clear();
        window.draw(map);
        window.display();
        
    }

    return 1;
}