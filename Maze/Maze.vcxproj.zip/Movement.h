#include <iostream>
	/*const int wall = 0;
	const int start = 1;
	const int exit = 2;
	const int road = 3;
	const int treaded = 4;
	*/
	

	int returning(int tab[], int current_pos, int current_number);
	int crossroads(int tab[], int current_pos, int choices[]);
	void movement(int tab[],int current_pos, int current_number)
	{ /*
		1. Check around for crossroad. 
		2. Check at the same time where road is located and if exit exists. ( void crossroads )
		3. If exit exists, end.
		4. If not. Move in the direction that's available. Right>Left>Up>Down
		5. Mark it as treaded path.
		6. Repeat 1
	  */
		//std::queue <int> crossroads;
		int solved = 0;
		int choices[4] = { 0,0,0,0 };
		//current_number = 4;
		solved = crossroads(tab, current_pos,choices);
		if(solved!=1) //solve loop
		{
			//changing number//
			if (solved > 0) { current_number++; }
			//Movement//
			tab[current_pos] = current_number; //poison
			if(choices[0]==3)
			{
				current_pos = current_pos + 1; //right
				movement(tab, current_pos, current_number);
			}
			else if (choices[1]==3)
			{
				
				current_pos = current_pos - 1; //left
				movement(tab, current_pos, current_number);
			}
			else if (choices[2]==3)
			{				
				current_pos = current_pos+22; //down
				movement(tab, current_pos, current_number);
			}
			else if (choices[3]==3)
			{
				current_pos = current_pos-22; //up
				movement(tab, current_pos, current_number);
			}
			else
			{
				current_pos=returning(tab,current_pos,current_number);
			}
			
		
		}
		else { std::cout << "Maze solved" << std::endl; }
	}

/*
	int up(int tab[], int current)
	{
		movement_y=(current-22);
	};

	void down(int tab[], int current)
	{
		movement_y=(current +22);
	};

	void left(int tab[], int current)
	{
		movement_x=(current -1);
	};

	void right(int tab[], int current)
	{
		movement_x=(current +1);
	};
	*/
	int crossroads(int tab[], int current_pos, int choices[])
	{
		int cross=0;
		int exit_found = 0;
		int temp=0;
		//std::cout << "Curr position = " << current_pos << std::endl;
		choices[0] = tab[current_pos + 1]; //right
		choices[1] = tab[current_pos - 1]; //left
		choices[2] = tab[current_pos + 22]; //down
		choices[3] = tab[current_pos - 22]; //up
		for(int i=0;i<4;i++)
		{
			if (choices[i] > 2) { cross++; }
			if (choices[i] == 2) { exit_found= 1; }
		}

		if (exit_found == 1) 
		{
			return exit_found; std::cout << "Found exit" << std::endl;
		}else if (cross > 2)
		{
			exit_found = 2;
			return exit_found; std::cout << "Found crossroad" << std::endl;
		}
		else {
			exit_found = 0; return exit_found; std::cout << "No crossroads" << std::endl;
		}

	};

	/*
	
	queue 

	int data;
	head=next;
	tail=previous;
	
	
	to crossroads:
	if crossroads. add XY to queue.

	if dead end. Go to the crossroad.
	Check if all sides of crossroad are done.
	If yes pop off queue and teleport to previous.

	*/

	int returning(int tab[], int current_pos, int current_number)
	{
		int x=0;
		std::cout << "Point of no return." << std::endl;

		for (int i = 0; i < 484; i++)
		{
			std::cout << tab[i];
			x++;
			if (x == 22) { x = 0; std::cout << std::endl; }
			else { std::cout << " , "; }
		}
			

		std::cin >> x;
		return x;
	};

